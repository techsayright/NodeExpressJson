
const List = class {
	constructor() {
		// doms
		this.form = document.querySelector('#itemForm');
		this.input = document.querySelector('#input');
		this.container =document.querySelector('.list');
        this.items= []; //ary
		this.init();
	}

	init() {
		
        fetch('/getitems')
            .then(response => response.json())
            .then(data => {
                console.log(data)
                this.items = data.items; //data.items ma items e db.json no che
                this.show();
            })
            .catch(err => console.log(err));

            $('#itemForm').on('submit', (e)=>{this.add(e)}) //when user click on submit
	}

    show() {
		this.items.forEach(item => {
			let newP= document.createElement("p");
			newP.innerHTML=`<p> ${item}</p>`;
			document.querySelector('.list').appendChild(newP);
        });
	}

	add(e){
		
        e.preventDefault(); //submit ne rokse bija ma jata
        const newItem = document.querySelector('#input').value;
        this.append(newItem);

        this.save(newItem);
	}


	append(item) {
        console.log(this.items, item);
        this.items.push(item);
        
        let newP= document.createElement("p");
        newP.innerHTML=`<p> ${item}</p>`;
        document.querySelector('.list').appendChild(newP);
    }

	save(item) {
		fetch('/setitems', {
			method: 'post',
			body: JSON.stringify({"newItem": item}),
			headers: {
				'Content-Type': 'application/json'
			}
		})
			.then(response => response.json())
			.then(data => {})
			.catch(err => console.log(err));
	}
};

new List();
