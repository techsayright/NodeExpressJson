const fs = require("fs");
const express = require("express");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(__dirname + '/public')); //pubic na html ne server pr launch kari skay

app.use(express.json());

app.get('/getitems',(req,res)=>{
    const data = JSON.parse(fs.readFileSync('db.json'));
    console.log(data);
    res.json(data); //ahiya send lakhiye ke json ek j kam kare
});

app.post('/setitems', (req,res)=>{
    const data = JSON.parse(fs.readFileSync('db.json')); //value buffer ma aavse so parse karine obj banavi nakhiye to te evo j aavse

    // const newData =data.items.push(req.body.newItem);
    data.items[data.items.length]= req.body.newItem; //aray ma value store kari


    fs.writeFileSync('db.json', JSON.stringify(data))
    // console.log(req.body);

    res.status(200).json({msg: "item saved"});

});

app.listen(PORT, ()=>{
    console.log("server is running on localhost:" + PORT);
})